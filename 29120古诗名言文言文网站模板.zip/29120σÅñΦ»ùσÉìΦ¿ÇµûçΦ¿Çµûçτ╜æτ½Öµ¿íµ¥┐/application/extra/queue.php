<?php

return array(
    'connector' => 'Sync'
);