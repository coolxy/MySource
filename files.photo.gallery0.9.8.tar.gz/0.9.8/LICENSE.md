
# Files Gallery / www.files.gallery

Copyright (c) 2020-2024 Imagevue Co Ltd - All Rights Reserved.

## Usage
You are free to download and use Files app as you like. Application can be used for free with some limitations. Full features available with paid license.

## Modifications
You are free to make modifications to the source, but support for custom modifications is not supported by the authors.

## Redistribution
You may not copy, redistribute or republish the source or a work based without consent from the author.

## Non-compliance
You may not copy, modify, sublicense, or distribute the application without consent from the author.

## Permissions
If you intend to incorporate the source code, in part or whole, into any free or proprietary program, you need to explicitly write to the original author(s) to ask for permission.

## No Warranty
The application is available "as is", and there is no warranty. The original author of the application is not liable to you for damaages arising out of the usage or inability to use the application.
