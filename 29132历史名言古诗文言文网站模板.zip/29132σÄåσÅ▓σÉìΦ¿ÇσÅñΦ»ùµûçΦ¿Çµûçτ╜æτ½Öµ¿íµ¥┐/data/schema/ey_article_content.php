<?php 
return array (
  'id' => 
  array (
    'name' => 'id',
    'type' => 'int(10)',
    'notnull' => false,
    'default' => NULL,
    'primary' => true,
    'autoinc' => true,
  ),
  'aid' => 
  array (
    'name' => 'aid',
    'type' => 'int(10)',
    'notnull' => false,
    'default' => '0',
    'primary' => false,
    'autoinc' => false,
  ),
  'content' => 
  array (
    'name' => 'content',
    'type' => 'longtext',
    'notnull' => false,
    'default' => NULL,
    'primary' => false,
    'autoinc' => false,
  ),
  'content_ey_m' => 
  array (
    'name' => 'content_ey_m',
    'type' => 'longtext',
    'notnull' => false,
    'default' => NULL,
    'primary' => false,
    'autoinc' => false,
  ),
  'add_time' => 
  array (
    'name' => 'add_time',
    'type' => 'int(11)',
    'notnull' => false,
    'default' => '0',
    'primary' => false,
    'autoinc' => false,
  ),
  'update_time' => 
  array (
    'name' => 'update_time',
    'type' => 'int(11)',
    'notnull' => false,
    'default' => '0',
    'primary' => false,
    'autoinc' => false,
  ),
  'chaodai' => 
  array (
    'name' => 'chaodai',
    'type' => 'enum(\'唐代\',\'宋代\',\'魏晋\',\'近现代\',\'南北朝\',\'清代\',\'明代\',\'元代\',\'两汉\',\'五代\',\'先秦\',\'金朝\',\'隋代\',\'未知\')',
    'notnull' => false,
    'default' => '唐代',
    'primary' => false,
    'autoinc' => false,
  ),
  'zuozhe' => 
  array (
    'name' => 'zuozhe',
    'type' => 'enum(\'李白\',\'杜甫\',\'苏轼\',\'王维\',\'杜牧\',\'陆游\',\'李煜\',\'元稹\',\'韩愈\',\'岑参\',\'齐己\')',
    'notnull' => false,
    'default' => '李白',
    'primary' => false,
    'autoinc' => false,
  ),
  'jianshang' => 
  array (
    'name' => 'jianshang',
    'type' => 'longtext',
    'notnull' => false,
    'default' => NULL,
    'primary' => false,
    'autoinc' => false,
  ),
  'zhaizi' => 
  array (
    'name' => 'zhaizi',
    'type' => 'varchar(500)',
    'notnull' => false,
    'default' => '',
    'primary' => false,
    'autoinc' => false,
  ),
  'jingbu' => 
  array (
    'name' => 'jingbu',
    'type' => 'enum(\'易类\',\'书类\',\'诗类\',\'礼类\',\'春秋类\',\'孝经类\',\'五经总义类\',\'四书类\',\'乐类\',\'小学类\')',
    'notnull' => false,
    'default' => '易类',
    'primary' => false,
    'autoinc' => false,
  ),
  'shibu' => 
  array (
    'name' => 'shibu',
    'type' => 'enum(\'正史类\',\'编年类\',\'纪事本末类\',\'杂史类\',\'别史类\',\'诏令奏议类\',\'传记类\',\'史钞类\')',
    'notnull' => false,
    'default' => '正史类',
    'primary' => false,
    'autoinc' => false,
  ),
  'jibu' => 
  array (
    'name' => 'jibu',
    'type' => 'enum(\'楚辞类\',\'别集类\',\'总集类\',\'诗文评类\',\'词曲类\')',
    'notnull' => false,
    'default' => '楚辞类',
    'primary' => false,
    'autoinc' => false,
  ),
  'zhuti' => 
  array (
    'name' => 'zhuti',
    'type' => 'enum(\'抒情\',\'四季\',\'食物\',\'典籍\',\'山水\',\'天气\',\'人物\',\'人生\',\'生活\',\'节日\',\'动物\',\'植物\')',
    'notnull' => false,
    'default' => '抒情',
    'primary' => false,
    'autoinc' => false,
  ),
);