#download js files for 0.8.4 to js/
wget https://cdn.jsdelivr.net/npm/toastify-js@1.12.0/src/toastify.min.js
wget https://cdn.jsdelivr.net/npm/sweetalert2@11.7.20/dist/sweetalert2.min.js
wget https://cdn.jsdelivr.net/npm/animejs@3.2.1/lib/anime.min.js
wget https://cdn.jsdelivr.net/npm/@exeba/list.js@2.3.1/dist/list.min.js
wget https://cdn.jsdelivr.net/npm/yall-js@3.2.0/dist/yall.min.js
wget https://cdn.jsdelivr.net/npm/filesize@9.0.11/lib/filesize.min.js
wget https://cdn.jsdelivr.net/npm/screenfull@5.2.0/dist/screenfull.min.js
wget https://cdn.jsdelivr.net/npm/dayjs@1.11.9/dayjs.min.js
wget https://cdn.jsdelivr.net/npm/dayjs@1.11.9/plugin/localizedFormat.js
wget https://cdn.jsdelivr.net/npm/dayjs@1.11.9/plugin/relativeTime.js
wget https://cdn.jsdelivr.net/npm/js-file-downloader@1.1.25/dist/js-file-downloader.min.js
wget https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js
wget https://cdn.jsdelivr.net/npm/file-saver@2.0.5/dist/FileSaver.min.js
wget https://cdn.jsdelivr.net/npm/codemirror@5.65.14/mode/meta.js
#wget https://cdn.jsdelivr.net/npm/files.photo.gallery@0.8.4/js/files.js

