<?php if(!defined('DIR')){header('HTTP/1.1 404 Not Found');header("status: 404 Not Found");exit;}
$sql ="
ALTER TABLE user_categorys 
ADD COLUMN category_type VARCHAR(255) NOT NULL DEFAULT 'link' COMMENT '分类类型' AFTER icon,
ADD COLUMN max VARCHAR(255) NOT NULL DEFAULT '' COMMENT '显示数量' AFTER category_type;
";

if(exe_sql($sql)){
    insert_db('updatadb_logs',['file_name'=>$file_name,'update_time'=>time(),'status'=>'TRUE','extra'=>'']);
}else{
    msg(-1,'数据库更新失败');
}
