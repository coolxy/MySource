<?php if(!defined('DIR')){header('HTTP/1.1 404 Not Found');header("status: 404 Not Found");exit;}AccessControl();

//热点新闻
if($GLOBALS['theme_info']['param']['hot_news'] == true || isset($_GET['hot'])){
    require DIR.'/system/expand/hot-news.php';
}

// 分类链接 | 书签分享 | 常规主页
if(isset($_GET['cid']) && intval($_GET['cid']) > 0){
    //检查分类ID是否存在
    if(!has_db('user_categorys',['uid'=>UID,'status'=>1,'cid'=>intval($_GET['cid'])])){
        $content = '未找到分类数据,请联系作者!';
        require DIR.'/templates/admin/page/404.php';;
        exit;
    }
    $Mode = 'category';
}elseif(isset($_GET['share']) && !empty($_GET['share'])){
    $share = get_db('user_share','*',['uid'=>UID,'sid'=>$_GET['share']]);
    if(empty($share)){
        $content = '分享已被删除,请联系作者!';
        require DIR.'/templates/admin/page/404.php';
        exit;
    }
    //判断是否过期
    if(time() > $share['expire_time']){
        $content = '分享已过期,请联系作者!';
        require DIR.'/templates/admin/page/404.php';;
        exit;
    }
    //判断是否加密
    if(!empty($share['pwd']) && !is_login()){
        session_start();
        if($_SESSION['verify']['share'][$share['id']] != $share['pwd']){
            $c = 'verify';$_GET['c'] = 'share';
            require DIR."/system/templates.php";
            require $index_path;
            exit;
        }
    }
    $share['data'] = json_decode($share['data']);
    $Mode = 'share';
}else{
    $Mode = 'home';
}

//是否为异步模式
$async = $GLOBALS['theme_info']['param']['async'];
if(!isset($async) || $async != true){
    $MIXED_DATA = Get_Data();
}

//分类页面生成分类数据
$categorys_data = $Mode == "category" ? Get_Data(['Mode'=>'categorys_data']): [];
$urls['home2'] = $Mode == 'category' ? $urls['home']:'';

//获取混合数据
function Get_Data($param = []) {
    //查找条件
    $category_where = ['uid' => UID, 'fid' => 0, 'status' => 1, 'ORDER' => ['weight' => 'ASC'], 'property' => (is_login ? [0,1] : 0) ];
    //读取字段
    $category_columns = ['cid(id)','fid','pid','name','property','font_icon','icon','description','category_type','max'];
    //分类格式 1: 单层分类 2: 双层分类
    $category_format = isset($param['category_format']) ? $param['category_format'] : ($GLOBALS['theme_info']['param']['category_format'] ?? 1); 
    //不支持虚拟分类
    if (!($GLOBALS['theme_info']['param']['virtual_category'] ?? true)) {
        $category_where['category_type'] = ['link','wz'];
    }
    //分类模式(仅查找指定分类ID)
    if(!isset($param['Mode']) && $GLOBALS['Mode'] == "category"){
        unset($category_where['fid']);
        $category_where['cid'] = intval($_GET['cid']);
    //书签分享
    }elseif(!isset($param['Mode']) && $GLOBALS['Mode'] == "share"){
        //分类分享
        if($GLOBALS['share']['type'] == 1){
            $category_where['property'] = $GLOBALS['share']['pv'] == 1 ? [0,1] : 0;
            $category_where['cid'] = $GLOBALS['share']['data'];
        }
        //链接分享
        if($GLOBALS['share']['type'] == 2){
            $MIXED_DATA = [['name' => $GLOBALS['share']['name'] ,"font_icon" =>"fa fa-bookmark-o" , "id" => 'share' ,"description" => "书签分享", "category_type" => "link"]];
            handle_link($MIXED_DATA[0]);
            return $MIXED_DATA;
        }
    }
    
    //查找一级分类
    $MIXED_DATA = select_db('user_categorys',$category_columns,$category_where);
    if(isset($param['Mode']) && $param['Mode'] == 'category_parent' ){
        return $MIXED_DATA;
    }
    //处理输出上限
    handle_category_max($MIXED_DATA,$param);
    //遍历查找二级分类
    foreach ($MIXED_DATA as &$category) {
        //修改查找条件并查找数据
        $category_where['fid'] = $category['id'];
        //分类分享限定查找范围
        $GLOBALS['Mode'] == "share" && $GLOBALS['share']['type'] == 1 && $category_where['cid'] = $GLOBALS['share']['data'];
        //查找数据
        $subitem = select_db('user_categorys',$category_columns,$category_where);
        //统计子分类数量
        $category['subitem_count'] = count_db('user_categorys',$category_where);
        //处理子分类继承属性和输出上限
        handle_subitem_category($subitem,$category);
        handle_category_max($subitem,$param);
        //加入或合并到父分类中
        if($category_format == 2){
            $category['subitem'] = $subitem;
        }else{
            $new_category_data [] = $category; 
            $new_category_data = array_merge ($new_category_data,$subitem);
        }
    }
    
    //单层分类重新赋值数据
    $category_format == 1 && $MIXED_DATA = $new_category_data;

    //仅获取分类数据
    if(isset($param['Mode']) && $param['Mode'] == 'categorys_data' || $GLOBALS['Mode'] == 'categorys_data'){
        return $MIXED_DATA;
    }
    
    //遍历分类下的链接
    foreach ($MIXED_DATA as &$category) {
        handle_link($category);
        if(!empty($category['subitem'])){
            foreach ($category['subitem'] as &$subitem_category) {
                handle_link($subitem_category);
            }
        }
    }
    
    
    //返回数据
    if($_GET['format'] == 'json'){
        msgA($MIXED_DATA);
    }else{
        return $MIXED_DATA;
    }
}

//处理子分类(继承加密和私有)
function handle_subitem_category(&$array, $parent_category) {
    foreach ($array as &$category) {
        if ($parent_category['pid'] > 0 && $category['pid'] == 0) {
            $category['pid'] = $parent_category['pid'];
        }
        if ($parent_category['property'] == 1) {
            $category['property'] = 1;
        }
    }
}
//处理分类超出隐藏
function handle_category_max(&$array,$param = []){
    foreach ($array as &$category) {
        if(in_array($category['category_type'],['link','link_new','link_top'])){
            $category['max'] = $category['max'] == '' ? intval($GLOBALS['site']['max_link']) : intval($category['max']);
        }else{
            $category['max'] = $category['max'] == '' ? intval($GLOBALS['site']['max_wz']) : intval($category['max']);
        }
        //最新或热门类未设置上限时默认为10
        if(in_array($category['category_type'],['link_new','link_top','wz_new','wz_top']) === true && $category['max'] === 0){
            $category['max'] = 10;
        }
        if(isset($param['max'])){
            $category['max'] = $param['max'];
        }
    }
}
//处理链接
function handle_link(&$array){
    global $site,$u,$share;
    $UUID = ($GLOBALS['global_config']['static_link'] == 2 ? UID : U);
    $param_u = $GLOBALS['global_config']['Default_User'] == U ? '' : "&u={$u}";
    $array['link_count'] = 0;
    $array['wz_count'] = 0;
    $array['link'] = [];
    //如果分类是链接
    if(in_array($array['category_type'],['link','link_new','link_top'])){
        //生成链接查询条件
        $where = ['uid' => UID, 'fid' => $array['id'], 'status' => 1, 'ORDER' => ['weight' => 'ASC','lid' => 'ASC'], 'property' => (is_login ? [0,1] : 0), 'LIMIT' => ($array['max'] == 0 ? 10000 : $array['max']) ];
        
        //排序模式
        if($array['category_type'] == 'link' && isset($site['link_sort']) && in_array($site['link_sort'],['lid|ASC','lid|DESC','up_time|ASC','up_time|DESC','click|ASC','click|DESC'])){
            list($key, $value) = explode('|', $site['link_sort']);
            $where['ORDER'] = [$key=>$value];
        }
        
        //如果不是常规链接则改变查找条件 (不含友情链接和导航菜单)
        if($array['category_type'] != 'link'){
            if(is_login){
                unset($where['fid']);
                $where['fid[<=]'] = 10000000;
            }else{
                $where['fid'] = get_open_category();
            }
        }
        //非常规模式(分类链接或书签分享)
        if($GLOBALS['Mode'] != "home"){
            //不限制数量
            unset($where['LIMIT']);
            //书签分享>链接分享
            if(isset($share['type']) && $share['type'] == 2){
                //仅查找指定的链接ID
                $where['lid'] = $share['data'];
                //如果私有可见
                if(isset($share['pv']) && $share['pv'] == 1){
                    unset($where['property']);
                    unset($where['fid']);
                }else{
                    $where['fid'] = get_open_category();
                }
            }
        }
        
        //根据分类类型修改查找条件
        if($array['category_type'] == 'link_new'){
            $where['ORDER'] = ['add_time' => 'DESC', 'lid' => 'DESC'];
        }elseif($array['category_type'] == 'link_top'){
            $where['ORDER'] = ['click' => 'DESC', 'lid' => 'DESC'];
        }
        //读取字段
        $columns = ['lid(id)','fid','property','title','url(real_url)','url_standby','description','icon','click','pid'];
        //已开启链接扩展且主题支持且有权限,则追加字段
        if( $GLOBALS['global_config']['link_extend'] == 1 && ($GLOBALS['theme_info']['param']['link_extend'] ?? false) && check_purview('link_extend',1)){
            $columns[] = 'extend';
        }
        //统计条数
        $array['link_count'] = $array['category_type'] == 'link' ? count_db('user_links',$where) : $array['max'];
        
        //查找数据并赋值
        $link_list  = select_db('user_links',$columns,$where);
        //处理继承属性/URL/图标/扩展
        foreach($link_list as &$link) {
            //重置标记
            $click = $lock = false;
            
            //直连模式时如果存在备用链接且未开启强制优先,则强制进入过渡页
            if($site['link_model'] == 'direct' && !empty($link['url_standby']) && $site['main_link_priority'] != '3' ){ $click = true; }
            
            //继承父分类私有属性
            if($array['property'] == 1){ $link['property'] = 1; }
            
            //继承父分类加密
            if($array['pid'] > 0 && $link['pid'] == 0){ $link['pid'] = $array['pid']; }
            
            //未登录且为加密链接
            if(is_login == false && $link['pid'] > 0){
                $click = $lock = true;
            }
            //生成过渡页链接
            if($click || $site['link_model'] != 'direct'){
                $link['url'] = static_link ? "{$GLOBALS['HOST']}/click-{$UUID}-{$link['id']}.html" : "./?c=click&id={$link['id']}{$param_u}";
                if($lock){
                    $link['real_url'] = $link['url'];
                    //书签分享加密链接时携带分享SID
                    if(isset($share['sid'])){
                        $link['url'] = static_link ? "{$GLOBALS['HOST']}/click-{$UUID}-{$link['id']}-sid{$share['sid']}.html" : "./?c=click&id={$link['id']}&share={$share['sid']}{$param_u}";
                    }
                }
            }else{
                $link['url'] = $link['real_url'];
            }
            //获取图标链接
            $link['ico'] = $lock ? $GLOBALS['libs'].'/Other/lock.svg' : geticourl($site['link_icon'],$link);

            //描述为空时调用站点设置
            if($link['description'] == '' &&  $site['link_desc'] != ''){
               $link['description'] = $site['link_desc'] == '{yiyan}' ? yiyan() : $site['link_desc'];
            }
            
            //处理扩展链接
            if(isset($link['extend']) && !empty($link['extend'])){
                $link = array_merge($link,unserialize($link['extend']));
            }
            $link['type'] = 'link';
            unset($link['url_standby']);
        }
        //赋值到分类
        $array['link'] = $link_list;
    }
    
    //符合条件时读取文章
    if(intval($array['id']) > 0 && intval($GLOBALS['global_config']['article']) > 0 && intval($site['article_visual'] ?? '1') > 0 && check_purview('article',1)){
        //生成文章查询条件
        $where = ['uid' => UID, 'category' => $array['id'], 'state' => (is_login ? [1,2] : 1), 'ORDER' => ['top' => 'ASC','id' => 'ASC'], 'LIMIT' => ($array['max'] == 0 ? 10000 : $array['max']) ];
        
        //排序模式
        if($array['category_type'] == 'wz' && isset($site['wz_sort']) && in_array($site['wz_sort'],['id|ASC','id|DESC','up_time|ASC','up_time|DESC','browse_count|ASC','browse_count|DESC'])){
            list($key, $value) = explode('|', $site['wz_sort']);
            $where['ORDER'] = [$key=>$value];
        }
        
        //根据分类类型修改查找条件
        if($array['category_type'] == 'wz_new'){
            unset($where['category']);
            $where['ORDER'] = ['add_time' => 'DESC', 'id' => 'DESC'];
        }elseif($array['category_type'] == 'wz_top'){
            unset($where['category']);
            $where['ORDER'] = ['browse_count' => 'DESC', 'id' => 'DESC'];
        }
        //非常规模式
        if($GLOBALS['Mode'] != "home"){
            unset($where['LIMIT']);
        }
        //读取字段
        $columns = ['id','category(fid)','state(property)','title','add_time','up_time','browse_count(click)','summary(description)','cover(ico)'];
        //统计条数
        $array['wz_count'] = count_db('user_article_list',$where);
        //查找数据并赋值
        $wz_list  = select_db('user_article_list',$columns,$where);
        //遍历数据
        foreach ($wz_list as &$wz) {
            //状态转私有属性
            $wz['property'] = $wz['property'] == 1 ? 0 : 1;
            //文章URL
            $wz['url'] = $wz['real_url'] = static_link ? "{$GLOBALS['HOST']}/article-{$UUID}-{$wz['id']}.html" : "./?c=article&id={$wz['id']}{$param_u}";
            //转义标题和摘要
            $wz['title'] = htmlspecialchars($wz['title'],ENT_QUOTES);
            $wz['description'] = htmlspecialchars($wz['description'],ENT_QUOTES);
            //文章图标
            if($site['article_icon'] == '1'){ //站点图标
                $wz['ico'] = $GLOBALS['favicon'];
            }elseif($site['article_icon'] == '2' && !empty($wz['ico'])){ //封面
                //存在封面保持不变
            }elseif($site['article_icon'] == '3'){ //封面
                $wz['ico'] = empty($wz['ico']) ? '//n1.lm21.top/wz/A'.rand(100, 200).'.jpg':$wz['ico'];
            }else{ //首字
                $wz['ico'] = './system/ico.php?text='.mb_strtoupper(mb_substr($wz['title'], 0, 1));
            }
            $wz['type'] = 'wz';
        }
        //根据设置合并到链接首尾
        if($site['article_visual'] == '1'){
            $array['link'] = array_merge($wz_list, $array['link']);
        }else{
            $array['link'] = array_merge($array['link'],$wz_list);
        }
    }
    
    //分类链接
    $array['category_url'] = static_link ? "{$GLOBALS['HOST']}/category-{$UUID}-{$array['id']}.html" : "./?cid={$array['id']}{$param_u}";
    $array['count'] = $array['link_count'] + $array['wz_count'];
    if( in_array($array['category_type'],['link','wz']) ){
        if(count($link_list ?? []) < $array['link_count'] || count($wz_list ?? []) < $array['wz_count']){
            if($GLOBALS['theme_info']['param']['generate_more'] ?? false){
                array_push($array['link'],['id'=>0,'title'=>'查看全部','url'=>$array['category_url'],'real_url'=>$array['category_url'],'description'=>"该分类共有{$array['count']}条数据",'ico'=>'./favicon.ico']);
            }
            $array['more'] = true;
        }else{
            $array['more'] = false;
        }
    }

    
}


//访问统计
write_user_count(date('Ym'),'index_Ym');
write_user_count(date('Ymd'),'index_Ymd');
count_ip();

//载入模板
require($index_path);