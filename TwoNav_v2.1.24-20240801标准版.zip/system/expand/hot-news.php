<?php 

//缓存路径
define('hot_path',DIR."/data/temp/hot.json");

//读取配置
$hot_news_config = unserialize(get_db("user_config", "v", ["k" => "hot_news_config","uid"=>$USER_DB['ID']]));

//阻止非正常访问
if(!isset($_SERVER['HTTP_HOST']) || empty($_SERVER['HTTP_HOST'])){
    exit();
}

//JS模式判断以及防盗链
if (isset($_GET['hot']) && $_GET['hot'] == 'default') {
    // if(empty($_SERVER['HTTP_REFERER']) || !strstr($_SERVER['HTTP_REFERER'],$_SERVER['HTTP_HOST'])){
    //     header('HTTP/1.1 404 Not Found');header("status: 404 Not Found");exit('404 Not Found');
    // }
    header('Cache-Control:no-cache,must-revalidate');
    header('Pragma:no-cache');   
    header('Expires:0'); 
    exit(hot_get_html());
}

//获取数据
function hot_get_html(){
    //缓存不存在或缓存过期时获取最新数据
    //缓存6分钟, 请勿修改缓存时间,频繁请求会导致IP被拉黑
    if((!is_file(hot_path) || filemtime(hot_path) + 360 < time()) && is_subscribe('bool') &&  $GLOBALS['global_config']['offline'] != '1'){
        
        $file = fopen(DIR.'/data/user/'.U.'/lock.'.UID,'w+');
        if(flock($file,LOCK_EX)){

            $config_list = json_decode($GLOBALS['hot_news_config']['list'], true);

            // 准备存放参数的数组
            $day_params = [];
            $hot_params = [];

            // 根据 config_list 的值生成参数
            foreach ($config_list as $key => $value) {
                if ($value[1] == true) {
                    if (in_array($key, ['60s', 'lunar', 'history'])) {
                        $day_params[] = $key;
                    } else {
                        $hot_params[] = $key;
                    }
                }
            }

            // 拼接参数为字符串
            $day_param_str = implode(',', $day_params);
            $hot_param_str = implode(',', $hot_params);

            // 请求最终生成的 URL
            $lytoday = ccurl("https://lytoday.lylme.com/?day={$day_param_str}&hot={$hot_param_str}",8,true);

            // 匹配 JavaScript 中的 HTML 片段
            preg_match_all('/<div class="hot-panel".*?>.*<\/div>/s', $lytoday['content'], $matches);
            $code = $matches[0];
            // 设置UTF-8编码，使能够识别中文
            $html = '<html><head><meta charset="UTF-8">
            <title>Document</title></head><body>' . implode('', $code) . '</body></html>';
            $doc = new DOMDocument();

            // 加载 HTML 内容
            @$doc->loadHTML($html);

            // 创建 DOMXPath 实例
            $xpath = new DOMXPath($doc);

            $data = [
                "data" => []
            ];

            // 提取60秒读懂世界数据
            function extractQuickReadData($xpath) {
                // 查找“60秒读懂世界”标题部分
                $titleNode = $xpath->query("//span[@class='hot-title' and text()='60秒读懂世界']")->item(0);
                if (!$titleNode) {
                    return []; // 如果没有找到标题则返回空数组
                }

                // 获取热搜容器的父节点
                $hotCard = $titleNode->parentNode->parentNode;

                // 提取数据
                $items = $xpath->query(".//ul[@class='hot-table']//li[@class='hot-list']", $hotCard);
                $quickReadData = [];

                foreach ($items as $item) {
                    $title = trim($xpath->query(".//a", $item)->item(0)->getAttribute('title'));
                    $quickReadData[] = $title;
                }

                return [
                    'data' => $quickReadData,
                    "time" => date('Y-m-d H:i:s')
                ];
            }

            function extractHotSearchData($xpath, $titleText) {
                // 查找热搜标题部分
                $titleNode = $xpath->query("//span[@class='hot-title' and text()='$titleText']")->item(0);
                if (!$titleNode) {
                    return null; // 如果没有找到标题则返回 null
                }

                // 获取热搜容器的父节点
                $hotCard = $titleNode->parentNode->parentNode;

                // 提取数据
                $items = $xpath->query(".//div[@class='hot-body']//li[@class='hot-list']", $hotCard);
                $hotData = [];

                $logo = trim($xpath->query(".//img", $hotCard)->item(0)->getAttribute('src'));
                $unit = trim($xpath->query(".//span[@class='hot-unit']", $hotCard)->item(0)->nodeValue);

                foreach ($items as $item) {
                    $index = trim($xpath->query(".//span[@class='hot-index']", $item)->item(0)->nodeValue);
                    $url = trim($xpath->query(".//a", $item)->item(0)->getAttribute('href'));
                    $title = trim($xpath->query(".//a", $item)->item(0)->nodeValue);
                    $desc = trim($xpath->query(".//a", $item)->item(0)->getAttribute('title'));
                    $hotScoreValue = intval(preg_replace('/[^0-9]/', '', trim($xpath->query(".//span[@class='hot-rank']", $item)->item(0)->nodeValue)));
                    $hotScore = $hotScoreValue !== 0 ? $hotScoreValue * 10000 : '';
                    $hotTagText = trim($xpath->query(".//span[contains(@class, 'hot-tag')]", $item)->item(0)->nodeValue);
                    if ($hotTagText == '新') {
                        $hotTag = 1;
                    } elseif ($hotTagText == '热') {
                        $hotTag = 3;
                    } elseif ($hotTagText == '首') {
                        $hotTag = 5;
                    } elseif ($hotTagText == '独') {
                        $hotTag = 8;
                    } elseif ($hotTagText == '谣') {
                        $hotTag = 16;
                    } else {
                        $hotTag = '';
                    }        
                    $hotTagName = trim($xpath->query(".//span[contains(@class, 'hot-tag')]", $item)->item(0)->nodeValue);

                    $hotData[] = [
                        'id' => $index,
                        'url' => $url,
                        'desc' => $desc,
                        'title' => $title,
                        'hotScore' => $hotScore,
                        'hotTag' => $hotTag,
                        'hotTagName' => $hotTagName // 如果有具体标签名称可以更新这里
                    ];
                }

                return [
                    "name" => $titleText,
                    "logo" => $logo,
                    "unit" => $unit,
                    'data' => $hotData,
                    "active_time" => date('Y-m-d H:i:s')
                ];
            }

            // 提取历史事件数据
            function extractHistoryData($xpath) {
                // 查找热搜标题部分
                $titleNode = $xpath->query("//span[@class='hot-title' and text()='历史上的今天']")->item(0);
                if (!$titleNode) {
                    return null; // 如果没有找到标题则返回 null
                }

                // 获取热搜容器的父节点
                $hotCard = $titleNode->parentNode->parentNode;

                // 提取数据
                $items = $xpath->query(".//div[@class='hot-body']//li[@class='hot-list']", $hotCard);
                $hotData = [];

                foreach ($items as $item) {
                    $year = trim($xpath->query(".//span[@class='span-year']", $item)->item(0)->nodeValue);
                    $link = trim($xpath->query(".//a", $item)->item(0)->getAttribute('href'));
                    $title = trim($xpath->query(".//a", $item)->item(0)->getAttribute('title'));
                    $target = trim($xpath->query(".//a", $item)->item(0)->nodeValue);

                    $historyData[] = [
                        'year' => $year,
                        'link' => $link,
                        'desc' => $desc,
                        'title' => $target
                    ];
                }

                return $historyData;
            }

            // 提取今日黄历数据
            function extractCalendarData($xpath) {
                // 查找“今日黄历”标题部分
                $titleNode = $xpath->query("//span[@class='hot-title' and text()='今日黄历']")->item(0);
                if (!$titleNode) {
                    return []; // 如果没有找到标题则返回空数组
                }

                // 获取热搜容器的父节点
                $hotCard = $titleNode->parentNode->parentNode;

                // 提取农历日期
                $lunarDateNode = $xpath->query(".//span[@class='hot-unit']", $hotCard)->item(0);
                $lunarDate = $lunarDateNode ? trim($lunarDateNode->nodeValue) : '';

                // 提取数据
                $items = $xpath->query(".//ul[@class='hot-table']//li[@class='hot-list']", $hotCard);
                $calendarData = [
                    'lunar_md' => $lunarDate,
                    'lunar_ymd' => '',
                    'lunar_nayin' => '',
                    'lunar_chongsha' => '',
                    'lunar_pengzu' => '',
                    'lunar_xishen' => '',
                    'lunar_fushen' => '',
                    'lunar_caishen' => '',
                    'lunar_jshen' => [],
                    'lunar_xshen' => [],
                    'lunar_yi' => [],
                    'lunar_ji' => []
                ];

                $fields = [
                    'lunar_ymd', 'lunar_nayin', 'lunar_chongsha', 'lunar_pengzu', 
                    'lunar_xishen', 'lunar_fushen', 'lunar_caishen', 
                    'lunar_jshen', 'lunar_xshen', 'lunar_yi', 'lunar_ji'
                ];

                foreach ($items as $index => $item) {
                    $content = $xpath->query(".//span[@class='span-lunar']", $item)->item(0)->C14N();
                    
                    if ($index >= 7) {
                        $calendarData[$fields[$index]] = array_map('trim', explode(' ', $content));
                    } else {
                        $calendarData[$fields[$index]] = $content;
                    }
                }

                return $calendarData;
            }


            // 提取各数据源的热搜数据
            if($config_list['60s'][1] == true) {$data['data']['60s'] = extractQuickReadData($xpath);}
            if($config_list['baidu'][1] == true) {$data['data']['baidu'] = extractHotSearchData($xpath, '百度热搜');}
            if($config_list['weibo'][1] == true) {$data['data']['weibo'] = extractHotSearchData($xpath, '微博热搜');}
            if($config_list['douyin'][1] == true) {$data['data']['douyin'] = extractHotSearchData($xpath, '抖音热点');}
            if($config_list['bilibili'][1] == true) {$data['data']['bilibili'] = extractHotSearchData($xpath, 'B站热搜');}
            if($config_list['zhihu'][1] == true) {$data['data']['zhihu'] = extractHotSearchData($xpath, '知乎热榜');}
            if($config_list['qqnews_hot'][1] == true) {$data['data']['qqnews_hot'] = extractHotSearchData($xpath, '腾讯新闻热点');}
            if($config_list['qqnews_curation'][1] == true) {$data['data']['qqnews_curation'] = extractHotSearchData($xpath, '腾讯新闻精选');}
            if($config_list['history'][1] == true) {$data['data']['history'] = extractHistoryData($xpath);}
            if($config_list['lunar'][1] == true) {$data['data']['lunar'] = extractCalendarData($xpath);}

            flock($file,LOCK_UN);
        }
        fclose($file);
        
        if($lytoday['code'] == 200){
            $datas = $data;
            $new_hot = true;
            file_put_contents(hot_path, json_encode($data, JSON_UNESCAPED_UNICODE));
        }
    }
    
    if(!isset($new_hot)){
        $hot_str = file_get_contents(hot_path);
        $datas = json_decode($hot_str, true);
        if(!is_array($datas)) return;
    }
    
    $config_list = json_decode($GLOBALS['hot_news_config']['list'], true);
    return hot_template_default($config_list,$datas);
}


function hot_template_default($config_list,$datas){
    $code = '<div class="hot-panel">';
    foreach($config_list as $alias => $config){
        //热榜
        if(in_array($alias,['baidu','weibo','douyin','bilibili','zhihu','qqnews_hot','qqnews_curation']) && $config[1] == true){
            $code .= "<div class='hot-card'><div class='hot-head'><img src='{$datas['data'][$alias]['logo']}'><span class='hot-title'>{$datas['data'][$alias]['name']}</span><span class='hot-unit'>{$datas['data'][$alias]['unit']}</span></div><div class='hot-body'><ul class='hot-table'>";
            $slices = $datas['data'][$alias]['data'];
            foreach ($slices as $slice) {
                $code .=   '<li class="hot-list"><span class="hot-index">' . $slice['id'] . '</span><a href="' . $slice['url'] . '" title="' . $slice['desc'] . '" target="_blank">' . $slice['title'] . '</a><span class="hot-rank">' . hot_formatNumber($slice['hotScore']) . '</span><span class="hot-tag hot-tag-' . $slice['hotTag'] . '">' . $slice['hotTagName'] . '</span></li>';
            }
            $code .=   '</ul></div><div class="hot-footer"><span class="hot-time">更新时间：' . hot_formatTime($datas['data'][$alias]['active_time']) . '</span></div></div>';
        //历史上的今天
        }elseif($alias == 'history' && $config[1] == true){
            $code .= ' <div class="hot-card"><div class="hot-head"><span class="hot-title">历史上的今天</span><span class="hot-unit"></span></div><div class="hot-body"><ul class="hot-table">';
            foreach ($datas['data'][$alias] as $item) {
                $code .= ' <li class="hot-list"><span class="span-year">' .  $item['year'] . '</span><a href="' . $item['link'] . '" title="' . $item['desc'] . '" target="_blank">' . $item['title'] . '</a></li>';
            }
            $code .= '</ul></div><div class="hot-footer"><span class="hot-time">更新时间：' . date("n月j日") . '</span></div></div>';
        //简讯
        }elseif($alias == '60s' && $config[1] == true){
            $code .= '<div class="hot-card"><div class="hot-head"><span class="hot-title">60秒读懂世界</span><span class="hot-unit">简讯</span></div><div class="hot-body"><ul class="hot-table">';
            if (!empty($datas['data'][$alias]['data'])) {
                foreach ($datas['data'][$alias]['data'] as $item) {
                    preg_match('/^(\d+)、(.+)；/', $item, $search);
                    if (array_key_exists(1, $search)) {
                        $code .= '<li class="hot-list"><span class="hot-index">' . $search[1] . '</span><a href="https://www.wuzhuiso.com/s?q=' . urlencode($search[2]) . '" title="' . $item . '" target="_blank">' . $search[2] . ' </a></li>';
                    } else {
                        $code .= '<li class="hot-list"><a href="#"">' . $item . '</a></li>';
                    }
                }
            } else {
                    $code .= '<li class="hot-list"><a href="#"> 获取数据失败</a></li>';
            }
            $code .=  '</ul></div><div class="hot-footer"><span class="hot-time">更新时间：' . date("m月d日", strtotime($datas['data'][$alias]['time'])) . '</span></div></div>';
        //黄历
        }elseif($alias == 'lunar' && $config[1] == true){
            $lunar = $datas['data'][$alias];
            $prefix = '<li class="hot-list"><span class="span-lunar">';
            $code .= '<div class="hot-card"><div class="hot-head"><span class="hot-title">今日黄历</span><span class="hot-unit"> '.$lunar['lunar_md'].'</span></div>';
            $code .= '<div class="hot-body"><ul class="hot-table">';
            $code .= $prefix.''.$lunar['lunar_ymd'].'</span> </li>';
            $code .= $prefix.'五行</span> '.$lunar['lunar_nayin'].'</li>';
            $code .= $prefix.'冲煞</span>'.$lunar['lunar_chongsha'].'</li>';
            $code .= $prefix.'彭祖</span>'.$lunar['lunar_pengzu'].'</li>';
            $code .= $prefix.'喜神</span> '.$lunar['lunar_xishen'].'</li>';
            $code .= $prefix.'福神</span> '.$lunar['lunar_fushen'].'</li>';
            $code .= $prefix.'财神</span>'.$lunar['lunar_caishen'].'</li>';
            $code .= $prefix.'吉神</span>'.implode('&#9;', $lunar['lunar_jshen']).'</li>';
            $code .= $prefix.'凶神</span>'.implode('&#9;', $lunar['lunar_xshen']).'</li>';
            $code .= $prefix.'<font color="green">宜</font></span>'.implode('&#9;', $lunar['lunar_yi']).'</li>';
            $code .= $prefix.'<font color="red">忌</font></span>'.implode('&#9;', $lunar['lunar_ji']).'</li>';
            $code .= '</ul></div><div class="hot-footer"><span class="hot-time"> '.$lunar['lunar_ymd'].'</span></div></div>';
        }
        
    }
    
    $style = '';
    if($GLOBALS['hot_news_config']['pc_style'] == '1'){
       $style = '<style>.hot-panel{display:flex;overflow-x:auto!important;flex-wrap:nowrap!important;justify-content:flex-start!important;align-content:center;}</style>';
    }
    if($GLOBALS['hot_news_config']['mobile_style'] == '1'){
       $style .= '<style>@media(max-width:768px){.hot-panel{flex-wrap:wrap!important;}}</style>'; 
    }
    $style .= $GLOBALS['hot_news_config']['style'];
    
    $code = '<style>#lytoday {text-align: left;}.hot-body::-webkit-scrollbar-thumb{background-color:#82828280;-webkit-border-radius:4px;border-radius:4px}.hot-body::-webkit-scrollbar{width:5px;height:2px}.hot-panel{display:flex;flex-wrap:wrap;justify-content:center;align-content:center}.hot-card{flex: 1;min-width:300px;margin:5px;padding:15px 20px 5px;width:20%;background:#fff;border-width:0;border-radius:10px;box-shadow:0px 0px 20px -5px #9e9e9e33}.hot-head{height:36px}.hot-head img{width:17px;height:17px;margin-right:5px;border-style:none;vertical-align:middle}.hot-title{font-size:16px;margin-bottom:8px;display:inline-block}.hot-unit{float:right;font-size:14px;color:#555555;margin-right:2rem}.hot-body{overflow:auto;overflow-x:hidden;height:360px;padding:5px}.hot-footer{margin-top:10px;border-top:1px solid #dddddd;padding:10px 0 0}.hot-time{float:right;color:#838383;font-size:14px;margin:2px}.hot-table{list-style-type:none;padding:0;margin:0}.hot-list{font-size:14px;min-height:1.8rem;padding:0;margin:0;display:flex}.hot-list:nth-of-type(1)>.hot-index:first-child{color:#fff;background:#FE2D46}.hot-list:nth-of-type(2)>.hot-index:first-child{color:#fff;background:#F60}.hot-list:nth-of-type(3)>.hot-index:first-child{color:#fff;background:#FAA90E}.hot-list a{width:80%;color:#333333;text-decoration:none}.hot-list a:hover{color:#f3434e}.hot-index{width:18px;height:18px;font-size:14px;text-align:center;margin-right:12px;border-radius:4px;color:#333;background:#dbdbdb;display:table;padding:0 3px}.span-year{padding:0px 3px;height:18px;font-size:14px;text-align:center;margin-right:12px;border-radius:4px;color:#333;background:#dbdbdb;display:inline-block}.hot-rank{white-space:nowrap;margin-left:auto;margin-right:5px;color:#939393}.hot-tag{width:18px;height:18px;border-radius:4px;text-align:center;font-size:12px;color:#fff;display:table;background:#ff9406;padding:1px}.hot-tag-1{background:#ff9406}.hot-tag-3{background:#ff3852}.hot-tag-5{background:#0bbd33}.hot-tag-8{background:#cb3aab}.hot-tag-16{background:#5f5f5f}.hot-tag-20{background:#ff9406}.hot-tag:empty{background:none}.hot-time i{margin-right:3px;font-style:normal}.span-lunar i{font-weight:bold;margin-right:5px;font-style:normal}.hot-list i{font-style:normal}.span-lunar{font-weight:bold;margin-right:15px;white-space:nowrap}.span-yan{text-indent:2em;line-height:1.5;font-size:16px}@media (max-width:768px){.hot-panel{flex-direction:row;overflow-x: auto; justify-content: flex-start;flex-wrap: nowrap;}.hot-card{width:100%}}</style>'.$style.$code.'</div>';
    //js模式
    if($GLOBALS['hot_news_config']['mode'] == '2'){
        return "var lytoday = document.getElementById('lytoday');\nlytoday.insertAdjacentHTML('afterbegin',`{$code}`);";
    //PHP模式
    }else{
        return $code;
    }
}

function hot_formatTime($time){
    $now = time(); 
    $time = strtotime($time);
    $timeDifference = $now - $time;
    if ($timeDifference < 60) {
        return '刚刚';
    }elseif($timeDifference < 3600) {
        $minutes = floor($timeDifference / 60);
        return $minutes . '分钟前';
    }elseif($timeDifference < 86400) {
        $hours = floor($timeDifference / 3600);
        return $hours . '小时前';
    }elseif($timeDifference < 201600) {
        $days = floor($timeDifference / 86400);
        if($days == 1) {
            return '昨天';
        }else{
            return '前天';
        }
    }else{
        $date = date('Y-m-d', $time);
        return $date;
    }
}

function hot_formatNumber($number){
    if (!is_numeric($number)) {
        return $number;
    }
    if ($number >= 10000) {
        $number = round($number / 10000);
        return $number . 'w';
    } elseif ($number >= 1000) {
        $number = round($number / 1000);
        return $number . 'k';
    }
    return $number;
}