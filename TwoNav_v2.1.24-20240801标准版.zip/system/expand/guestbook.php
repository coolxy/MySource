<?php 
if($global_config['guestbook'] != 1 || !check_purview('guestbook',1)){
    require DIR.'/templates/admin/page/404.php';
    exit;
}

$s = unserialize( get_db("user_config", "v", ["k" => "guestbook","uid"=>UID]) );
if(empty($s) || $s['allow'] != 1){
    $content = '站点已设置禁止留言';
    require DIR.'/templates/admin/page/404.php';
    exit;
}
if(!Check_Path("data/user/{$u}/MessageBoard")){
    exit("<h2>创建目录失败,请检查权限</h2>");
}

//验证码
if(isset($_GET['captcha'])){
    session_start();
    header("Content-type:image/PNG");
    $_SESSION["{$u}_{$c}_captcha"] = '';
    $im = imagecreate(60,30);
    $back = imagecolorallocate($im, 245, 245, 245);
    $captcha = '';
    imagefill($im, 0,0, $back);
    for($i = 0; $i < 4; $i++){
        $font = imagecolorallocate($im, rand(100, 255), rand(0, 100), rand(100, 255));
        $authnum = rand(0, 9);
        $_SESSION["{$u}_{$c}_captcha"] .= "{$authnum}";
        imagestring($im, 5, 8 + $i * 12, 8, $authnum, $font);
    }
    
    for($i=0;$i<600;$i++) {
        $font = imagecolorallocate($im, rand(0, 255), rand(0, 255), rand(0, 255));
        imagesetpixel($im, rand()%150, rand()%150, $font);
    }
    imagepng($im);
    imagedestroy($im); 
}

//POST提交留言
if($_SERVER['REQUEST_METHOD'] === 'POST'){
     if($s['allow'] != '1'){ msg(-1,'提交失败,当前禁止留言!');  }
     $type = $_POST['type']; //类型
     $contact = $_POST['contact']; //联系方式
     $title = $_POST['title']; //标题
     $content = $_POST['content']; //内容
     session_start();
     if(empty($type)){
         msg(-1,'提交失败,类型不能为空');
     }elseif(empty($contact)){
         msg(-1,'提交失败,联系方式不能为空');
     }elseif(empty($title)){
         msg(-1,'提交失败,标题不能为空');
     }elseif(empty($content)){
         msg(-1,'提交失败,内容不能为空');
     }elseif(strlen($type) >= 32 || strlen($contact) >= 64 || strlen($title) >= 128 || strlen($content) >= 2048){
         msg(-1,'提交失败,长度超限');
     }elseif(!preg_match('/[\x{4e00}-\x{9fa5}]+/u', $content)){
         msg(-1,'提交失败,反馈内容必须使用中文');
     }elseif($_SESSION["{$u}_{$c}_captcha"] != $_POST['captcha']){
         msg(-1,'验证码错误');
     }elseif(ShuLiang("data/user/{$u}/MessageBoard/") > 256){
         msg(-1,'提交失败,留言太多了请稍后再试');
     }
     $_SESSION[$u]['captcha'] = '';
     $json_arr = array(
         'type'=>htmlentities($type),
         'contact'=>htmlentities($contact),
         'title'=>htmlentities($title),
         'content'=>htmlentities($content),
         'time'=>time(),
         'ip'=>get_IP()
         );
         //限制长度 参数
     //var_dump($json_arr);exit;
     $json = json_encode($json_arr);
     $path = "data/user/{$u}/MessageBoard/".time().'_'.crc32($json).'.json';
     if( Check_Path("data/user/{$u}/MessageBoard") && file_put_contents($path, $json)){
        msg(1,'提交成功'); 
    }else{
        msg(-1,'系统错误,提交失败'); //创建目录或写入文件失败,请检查权限
    }
 } 

//获取文件数
function ShuLiang($path){
    $sl=0;
    $arr = glob($path);
    foreach ($arr as $v){
        if(is_file($v)){
            $sl++;
        }else{
            $sl+=ShuLiang($v."/*");
        }
    }
    return $sl;
}

//通用数据初始化
require DIR."/system/templates.php";
require $index_path;
exit;