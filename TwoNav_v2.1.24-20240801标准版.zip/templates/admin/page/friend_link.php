<?php $title='友情链接';$awesome=true; require 'header.php';  ?>
<style>
    .layui-table-tool-temp  {padding-right:1px;}

</style>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">
        <table id="table" class="layui-table" lay-filter="table" style="margin: 1px 0;"></table>
    </div>
</div>
<!-- 表头工具栏 -->
<script type="text/html" id="toolbar">
    <div class="layui-btn-group">
        <button class="layui-btn layui-btn-sm layui-btn-danger layui-hide-xs" lay-event="refresh">刷新</button>
        <button class="layui-btn layui-btn-sm " lay-event="add">新增</button>
        <button class="layui-btn layui-btn-sm" lay-event="up_top">到顶</button>
        <button class="layui-btn layui-btn-sm" lay-event="down_bottom">到底</button>
        <button class="layui-btn layui-btn-sm layui-btn-warm" lay-event="up_tr">上移</button>
        <button class="layui-btn layui-btn-sm layui-btn-warm" lay-event="down_tr">下移</button>
        <button class="layui-btn layui-btn-sm layui-btn-normal" lay-event="save" id="btn-save">保存</button>
        <button class="layui-btn layui-btn-sm" lay-event="tip" id="btn-save">提示</button>
    </div>
</script>
<!-- 操作列 -->
<script type="text/html" id="tablebar">
    <div class="layui-btn-group">
        <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edit">编辑</a>
        <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a>
    </div>
</script>
<script src = "<?php echo $libs;?>/jquery/jquery-3.6.0.min.js"></script>
<script src = "./templates/admin/js/public.js?v=<?php echo $Ver;?>"></script>
<?php load_static('js');?>
<script src = "./templates/admin/js/friend_link.js?v=<?php echo $Ver;?>"></script>
</body>
</html>
<ul class="friend_links" style = "margin-top:18px;display:none;padding-right: 10px;" >
    <form class="layui-form layuimini-form" lay-filter="edit">
        <input type="text" name="id" style="display:none;">
        <div class="layui-form-item">
            <label class="layui-form-label required">标题</label>
            <div class="layui-input-block">
                <input type="text" name="title" lay-verify="required" placeholder="请输入标题" class="layui-input">
            </div>
        </div>
    
        <div class="layui-form-item">
            <label class="layui-form-label required">链接</label>
            <div class="layui-input-block">
                <input type="text" name="url" lay-verify="required" placeholder="请输入链接" class="layui-input">
            </div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">描述</label>
            <div class="layui-input-block">
                <input type="text" name="description" placeholder="请输入描述" class="layui-input">
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label"></label>
            <span>友情链接仅部分主题支持,通常在底部显示</span>
        </div>
        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn layui-btn-warm" type="button" id="close" >关闭</button>
                <button class="layui-btn layui-btn-normal" lay-submit lay-filter="save" >保存</button>
            </div>
        </div>
  </form>
</ul>