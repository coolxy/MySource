<?php $title='导航菜单';$awesome=true; require 'header.php';  ?>
<style>
    .layui-table-tool-temp  {padding-right:1px;}

</style>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">
        <table id="table" class="layui-table" lay-filter="table" style="margin: 1px 0;"></table>
    </div>
</div>
<!-- 表头工具栏 -->
<script type="text/html" id="toolbar">
    <div class="layui-btn-group">
        <button class="layui-btn layui-btn-sm layui-btn-danger layui-hide-xs" lay-event="refresh">刷新</button>
        <button class="layui-btn layui-btn-sm " lay-event="add">新增</button>
        <button class="layui-btn layui-btn-sm" lay-event="up_top">到顶</button>
        <button class="layui-btn layui-btn-sm" lay-event="down_bottom">到底</button>
        <button class="layui-btn layui-btn-sm layui-btn-warm" lay-event="up_tr">上移</button>
        <button class="layui-btn layui-btn-sm layui-btn-warm" lay-event="down_tr">下移</button>
        <button class="layui-btn layui-btn-sm layui-btn-normal" lay-event="save" id="btn-save">保存</button>
        <button class="layui-btn layui-btn-sm" lay-event="tip" id="btn-save">提示</button>
    </div>
</script>
<!-- 操作列 -->
<script type="text/html" id="tablebar">
    <div class="layui-btn-group">
        <a class="layui-btn layui-btn-normal layui-btn-xs" lay-event="edit">编辑</a>
        <a class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del">删除</a>
    </div>
</script>
<script src = "<?php echo $libs;?>/jquery/jquery-3.6.0.min.js"></script>
<script src = "./templates/admin/js/public.js?v=<?php echo $Ver;?>"></script>
<?php load_static('js');?>
<script src = "./templates/admin/js/nav_menu.js?v=<?php echo $Ver;?>"></script>
</body>
</html>
<ul class="nav_menu" style = "margin-top:18px;display:none;padding-right: 10px;" >
    <form class="layui-form layuimini-form" lay-filter="edit">
        <input type="text" name="id" style="display:none;">
        <div class="layui-form-item">
            <label class="layui-form-label required">菜单标题</label>
            <div class="layui-input-block">
                <input type="text" name="title" lay-verify="required" placeholder="请输入标题" class="layui-input">
            </div>
        </div>
    
        <div class="layui-form-item">
            <label class="layui-form-label required">菜单链接</label>
            <div class="layui-input-block">
                <input type="text" name="url" lay-verify="required" placeholder="请输入链接" class="layui-input">
            </div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">生效条件</label>
            <div class="layui-input-block">
                <select name="property" >
                    <option value="0" selected="">无条件</option>
                    <option value="1">已登录时显示</option>
                    <option value="2">未登录时显示</option>
                </select> 
            </div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">打开方式</label>
            <div class="layui-input-block">
                <select name="target">
                    <option value="_self" >当前窗口打开</option>
                    <option value="_blank" selected="">新窗口打开</option>
                </select> 
            </div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">菜单描述</label>
            <div class="layui-input-block">
                <input type="text" name="description" placeholder="请输入描述" class="layui-input">
            </div>
        </div>
        
        <div class="layui-form-item">
            <label class="layui-form-label">扩展参数</label>
            <div class="layui-input-block">
                <textarea name="extend" placeholder="建议使用JSON格式,具体写法请根据主题特性和要求而定,如果您不理解其作用请留空" class="layui-textarea"></textarea>
            </div>
        </div>
        <div class="layui-form-item">
            <label class="layui-form-label"></label>
            <span>导航菜单仅部分主题支持,通常在顶部显示,也有部分主题会在左侧或底部显示</span>
        </div>
        

        <div class="layui-form-item">
            <div class="layui-input-block">
                <button class="layui-btn layui-btn-warm" type="button" id="close" >关闭</button>
                <button class="layui-btn layui-btn-normal" lay-submit lay-filter="save" >保存</button>
            </div>
        </div>
  </form>
</ul>