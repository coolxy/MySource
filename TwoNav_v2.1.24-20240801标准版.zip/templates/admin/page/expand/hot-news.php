<?php 
require dirname(__DIR__).'/header.php'  ?>
<style>
.footer{
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    padding: 10px;
    background-color: #fff;
    border-top: 1px solid #e6e6e6;
    z-index: 1;
}
</style>
<body>
<div class="layuimini-container">
    <div class="layuimini-main">
        <form class="layui-form" lay-filter="form">
            <div class="layui-form layuimini-form layui-form-pane">
                <div class="layui-form-item">
                    <label class="layui-form-label">工作模式</label>
                    <div class="layui-input-inline" >
                        <select lay-verify="required" name="mode">
                            <option value="0" selected="">关闭</option>
                            <option value="2">JS模式 (推荐)</option>
                            <option value="1">PHP模式</option>
                        </select>
                    </div>
                    <div class="layui-form-mid layui-word-aux">部分模板支持热点新闻</div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">电脑端样式</label>
                    <div class="layui-input-inline" >
                        <select lay-verify="required" name="pc_style">
                            <option value="0" selected="">多排显示</option>
                            <option value="1">单排显示</option>
                        </select>
                    </div>
                    <div class="layui-form-mid layui-word-aux">多排显示时可以按住shift+鼠标滚轮横向滚动</div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">手机端样式</label>
                    <div class="layui-input-inline" >
                        <select lay-verify="required" name="mobile_style">
                            <option value="0" selected="">横向显示</option>
                            <option value="1">竖向显示</option>
                        </select>
                    </div>
                    <div class="layui-form-mid layui-word-aux">横排显示时左右滑动,竖排显示时上下滑动</div>
                </div>
                <div class="layui-form-item" style="display:none;">
                    <label class="layui-form-label">模板类型</label>
                    <div class="layui-input-inline" >
                        <select lay-verify="required" name="template">
                            <option value="default" selected="">默认模板</option>
                        </select>
                    </div>
                    <div class="layui-form-mid layui-word-aux">给未来添加模板做准备</div>
                </div>
                <div class="layui-form-item layui-form-text">
                    <label class="layui-form-label">自定义CSS样式</label>
                    <div class="layui-input-block">
                        <textarea class="layui-textarea" name="style" placeholder="减小高度示例:
<style>.hot-body{height:360px!important;}</style>"></textarea>
                    </div>
                </div>
                <div class="layui-form-item layui-form-text" style="display:none;">
                    <label class="layui-form-label">列表配置</label>
                    <div class="layui-input-block">
                        <textarea class="layui-textarea" name="list"></textarea>
                    </div>
                </div>
            </div>
        </form>
        <table id="table" class="layui-table" lay-filter="table"></table>
    </div>
</div>

<script type="text/html" id="toolbar">
    <div class="layui-btn-group">
        <button class="layui-btn layui-btn-sm" lay-event="up_top">到顶</button>
        <button class="layui-btn layui-btn-sm" lay-event="down_bottom">到底</button>
        <button class="layui-btn layui-btn-sm layui-btn-warm" lay-event="up_tr">上移</button>
        <button class="layui-btn layui-btn-sm layui-btn-warm" lay-event="down_tr">下移</button>
        <button class="layui-btn layui-btn-sm" lay-event="tip">提示</button>
        <button class="layui-btn layui-btn-sm layui-btn-normal" lay-event="save">保存</button>
    </div>
</script>
<script type="text/html" id="state-switch">
    <input type="checkbox" name="status" value="{{= d.state }}" title="是|否" lay-skin="switch" lay-filter="state-switch" {{= d.state == true ? "checked" : "" }}>
</script>
<script src="<?php echo $libs;?>/jquery/jquery-3.6.0.min.js"></script>
<script src="./templates/admin/js/public.js?v=<?php echo $Ver;?>"></script>
<?php load_static('js');?>

<script>
layui.use(function () {
    var form = layui.form;
    var upload = layui.upload;
    var table = layui.table;
    var data_tr;
    //表单赋值
    form.val('form', <?php echo json_encode(unserialize(get_db("user_config", "v", ["k" => "hot_news_config","uid"=>$USER_DB['ID']])));?>);
    
    //读取配置
    var list_json = $("textarea[name='list']").val();
    try { 
        JSON.parse(list_json);
    } catch (e) {
        list_json = '{"60s":[1,false],"baidu":[2,true],"weibo":[3,true],"douyin":[4,true],"bilibili":[5,false],"zhihu":[6,true],"qqnews_hot":[7,false],"qqnews_curation":[8,false],"history":[9,false],"lunar":[10,false]}';
    }
    
    var list_config = JSON.parse(list_json);
    var list = [
        { name: "60s", title: "60秒读懂世界", weight: 1, state: true },
        { name: "baidu", title: "百度热搜", weight: 2, state: true },
        { name: "weibo", title: "微博热搜", weight: 3, state: true },
        { name: "douyin", title: "抖音热点", weight: 4, state: true },
        { name: "bilibili", title: "B站热搜", weight: 5, state: true },
        { name: "zhihu", title: "知乎热搜", weight: 6, state: true },
        // { name: "qqnews_hot", title: "腾讯新闻热点", weight: 7, state: true },
        // { name: "qqnews_curation", title: "腾讯新闻精选", weight: 8, state: true },
        { name: "history", title: "历史上的今天", weight: 9, state: false },
        { name: "lunar", title: "今日黄历", weight: 10, state: false }
    ];
    
    list.forEach(function(item) {
        var config = list_config[item.name];
        if (config) {
            item.weight = config[0];
            item.state = config[1];
        } else {
            item.weight = 0; 
            item.state = true;
        }
    });

    list.sort(function(a, b) { return a.weight - b.weight});
    
    //表格渲染
    table.render({
        elem: '#table',
        data: list,
        toolbar: '#toolbar',
        defaultToolbar: false,
        page: false,
        cols: [[
            {type:'radio', hide:false},
            {field: 'name', title: '字段', width: 128, hide:true},
            {field: 'state', title: '是否显示', width:100, templet: '#state-switch',align: 'center'},
            {field: 'title', title: '名称'}
        ]]
    });
    
    //行点击事件
    table.on('row(table)', function(obj) {
	   obj.setRowChecked({type: 'radio'});
	   tr = $(this);
    });
    table.on('radio(table)', function(obj){
	   tr = $(this).parent().parent().parent();
    });

    //监听工具栏
    table.on('toolbar(table)', function (obj) {
        if(obj.event == 'tip'){
            layer.alert("1.选中需要排序的内容<br />2.按需移动数据位置<br />3.移动好了点击保存即可<br />注: 仅部分模板支持此功能",{title:'排序提示',anim: 5,closeBtn: 0,btn: ['知道了']});
            return;
        }else if(obj.event == 'save'){
            save_config();
            return;
        }
        var checkStatus = table.checkStatus(obj.config.id);
        if(checkStatus.data.length == 0) {
            layer.msg('未选中任何数据！');
            return;
        }
        table_tr_move(obj.event);
    });
    
    function table_tr_move(type){
        if(type == 'up_tr' || type == 'up_top'){
            if($(tr).prev().html() == null){
                layer.msg("已经是最顶部了");
                return;
            }
            if(type == 'up_tr'){
                $(tr).insertBefore($(tr).prev()); 
            }else if(type == 'up_top'){
                $(tr).insertBefore($(tr).siblings(":first"));
            }
        }else if(type == 'down_tr' || type == 'down_bottom'){
            if($(tr).next().html() == null){
                layer.msg("已经是最底部了");
                return;
            }
            if(type == 'down_tr'){
                $(tr).insertAfter($(tr).next());
            }else if(type == 'down_bottom'){
                $(tr).insertAfter($(tr).siblings(":last"));
            }
        }else{
            layer.msg("type参数错误");
            return;
        }
    }
    function updateSortData() {
        let data = {},weight  = 0,state;
        $('.layui-table-main tr').each(function(i){
            weight++;
            let name = $(this).find('[data-field="name"]').text();
            let state = ($(this).find('[data-field="state"]').text().trim() == '是');
            data[name] = [weight, state];
        });
        data = JSON.stringify(data);
        return data;
    }
    //保存配置
    function save_config() {
        let loading = layer.msg('正在保存..', {icon: 16,time: 1000*300,shadeClose: false});
        let config = form.val('form');
        config.list = updateSortData();
        $.post(get_api('write_hot_news','save_config'),config,function(data,status){
            layer.close(loading);
            if(data.code == 1) {
                layer.msg((config.mode == '0' ? '工作模式为关闭<br />':'') + data.msg , {icon: 1});
            }else{
                layer.msg(data.msg || '未知错误',{icon: 5});
            }
        });
        return false;
    }
    
});

</script>
</body>
</html>