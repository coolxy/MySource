layui.use(['form','table'], function () {
    var form = layui.form;
    var table = layui.table;
    var tr;
    var api = get_api('read_nav_menu'); //列表接口

    var cols=[[ //表头
      {type:'radio', hide:false}
      ,{field:'id', title: 'ID', width:80, hide:true}
      ,{field:'title', title: '链接标题', width:200}
      ,{title:'操作',toolbar:'#tablebar',width:110}
      ,{field:'add_time', title: '添加时间', width:166,templet:function(d){return timestampToTime(d.add_time);}}
      ,{field:'up_time',title:'修改时间',width:166,templet:function(d){return timestampToTime(d.up_time)}}
      ,{field:'url', title: 'URL', minWidth : 200}
      ,{field:'description', title: '描述', minWidth : 200}
    ]];
    
    //渲染表格
    table.render({
        elem: '#table'
        ,height: 'full-40' //自适应高度
        ,url: api //数据接口
        ,where: {fid:$("#fid").val()}
        ,page: true //开启分页
        ,loading:true //加载条
        ,defaultToolbar:false
        ,toolbar: '#toolbar'
        ,id:'table'
        ,cols: cols
        ,method: 'post'
        ,skin : 'line'
        ,response: {statusCode: 1 } 
        ,done: function (res, curr, count) {
            $("[data-field='0']").addClass('layui-hide-xs');
            $("[data-field='description']").addClass('layui-hide-xs');
            $("[data-field='add_time']").addClass('layui-hide-xs');
            $("[data-field='up_time']").addClass('layui-hide-xs');
            $(".layui-laypage-count").text('菜单总数: ' + count );
            //删除底部的分页元素
            $(".layui-laypage-skip").remove(); 
            $(".layui-laypage-limits").remove();
            $(".layui-laypage-curr").remove();
            $(".layui-table-page a").remove();
            $(".layui-laypage-prev").remove();
            $(".layui-laypage-next").remove();
        }
    });
    
    //行点击事件
    table.on('row(table)', function(obj) {
	   obj.setRowChecked({type: 'radio'});
	   tr = $(this);
    });
    table.on('radio(table)', function(obj){
	   tr = $(this).parent().parent().parent();
    });
    //监听工具栏
    table.on('toolbar(table)', function (obj) {
        var checkStatus = table.checkStatus(obj.config.id);
        if( checkStatus.data.length == 0 && ['refresh','add','save','tip'].indexOf(obj.event) == -1 ) {
            layer.msg('未选中任何数据！');
            return;
        }
        if(obj.event == 'refresh'){
            table.reload('table');
        }else if(obj.event == 'save'){
            updateSortData();
        }else if(obj.event == 'tip'){
            layer.alert("1.选中需要排序的链接<br />2.按需移动数据位置<br />3.移动好了点击保存即可<br />注: 仅部分模板支持导航菜单",{title:'排序提示',anim: 5,closeBtn: 0,btn: ['知道了']});
        }else if(obj.event == 'add'){
            form.val('edit', {'id':'0','title':'','url':'','description':'','extend':''});
            index = layer.open({type: 1,scrollbar: false,shadeClose: true,title: '添加菜单',area : ['100%','100%'],content: $('.nav_menu')});
        }else{
            table_tr_move(obj.event);
        }
    });
    
    table.on('tool(table)', function(obj){ 
        var data = obj.data;
        if(obj.event === 'edit'){
            form.val('edit', obj.dataCache);
            index = layer.open({type: 1,scrollbar: false,shadeClose: true,title: '修改菜单',area : ['100%','100%'],content: $('.nav_menu')});
        }else if(obj.event === 'del'){
            layer.confirm('确认删除?',{icon: 3, title:'温馨提示'}, function(index){
                $.post(get_api('write_nav_menu','del'),{id:obj.data.id},function(data,status){
                    if(data.code == 1) {
                        table.reload('table');
                        layer.msg(data.msg,{icon:1});
                    }else{
                        layer.msg(data.msg,{icon:5});
                    }
                });
            });
        }
    });
    
    //保存排序
    function updateSortData() {
        let new_datas = [];
        let weight = 0;
        $('table tr td[data-field="id"]').each(function(i){
            weight++;
            new_datas.push($(this).text());
        });
        if(new_datas.length == 0){
            layer.msg("表格无数据",{icon:5});
            return;
        }
        console.log(JSON.stringify(new_datas));
        $.post(get_api('write_nav_menu','sort'),{data:new_datas},function(data,status){
            if(data.code == 1) {
                table.reload('table');
                layer.msg(data.msg,{icon:1});
            }else{
                layer.msg(data.msg,{icon:5});
            }
        });
    }

    function table_tr_move(type){
        if(type == 'up_tr' || type == 'up_top'){
            if($(tr).prev().html() == null){
                layer.msg("已经是最顶部了");
                return;
            }
            if(type == 'up_tr'){
                $(tr).insertBefore($(tr).prev()); 
            }else if(type == 'up_top'){
                $(tr).insertBefore($(tr).siblings(":first"));
                roll_tr($(tr).attr("data-index"));
            }
        }else if(type == 'down_tr' || type == 'down_bottom'){
            if($(tr).next().html() == null){
                layer.msg("已经是最底部了");
                return;
            }
            if(type == 'down_tr'){
                $(tr).insertAfter($(tr).next());
            }else if(type == 'down_bottom'){
                $(tr).insertAfter($(tr).siblings(":last"));
                roll_tr($(tr).attr("data-index"));
            }
        }else{
            layer.msg("type参数错误");
            return;
        }
    }
   
    //滚动到指定行
    function roll_tr(index) {
        let cellHtml = $(".layui-table-main").find("tr[data-index=" + index + "]");
        let cellTop = cellHtml.offset().top;
        $(".layui-table-main").scrollTop(cellTop - 160);
    }

    //保存
    form.on('submit(save)', function (data) {
        $("*").blur();
        let type = data.field.id == '0' ? 'add' : 'edit';
        $.post(get_api('write_nav_menu',type),data.field,function(data,status){
            if(data.code == 1) {
                layer.close(index);
                table.reload('table');
                layer.msg(data.msg, {icon: 1});
            }else{
                layer.msg(data.msg, {icon: 5});
            }
        });
        return false;
    });
    
    $("#close").click(function() {
        layer.close(index);
    });

});
