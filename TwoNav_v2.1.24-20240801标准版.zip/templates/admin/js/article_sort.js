layui.use(['form','table'], function () {
    var form = layui.form;
    var table = layui.table;
    var data_tr,table_page;
    var api = get_api('read_article','article_list') ; //列表接口
    var state_data = ["Null","公开", "私有", "草稿", "废弃"];
    
    var cols=[[ //表头
      {type:'radio'} //开启单选框
      ,{field: 'id', title: 'ID', width:80, sort: true,hide:true}
      ,{field: 'top', title: '权重', width:80, sort: true,hide:true}
      ,{field: 'title', title: '文章标题', width:300}
      ,{field:'state',title:'状态',width:100,templet: function(d){
          return state_data[d.state];
      }}
      ,{field: 'summary', title: '文章摘要',minWidth:200}
    ]];
    
    //渲染表格
    table.render({
        elem: '#table'
        ,height: 'full-80' //自适应高度
        ,url: api //数据接口
        ,where: {category:$("#fid").val(),limit:99999}
        ,page: true //开启分页
        ,loading:true //加载条
        ,defaultToolbar:false
        ,toolbar: '#toolbar'
        ,id:'table'
        ,cols: cols
        ,method: 'post'
        ,response: {statusCode: 1 }
        ,done: function (res, curr, count) {
            $("[data-field='0']").addClass('layui-hide-xs');
            $("[data-field='description']").addClass('layui-hide-xs');
            $("[data-field='add_time']").addClass('layui-hide-xs');
            $("[data-field='up_time']").addClass('layui-hide-xs');
            $(".layui-laypage-count").text('当前分类文章总数: ' + count );
            //删除底部的分页元素
            $(".layui-laypage-skip").remove(); 
            $(".layui-laypage-limits").remove();
            $(".layui-laypage-curr").remove();
            $(".layui-table-page a").remove();
            $(".layui-laypage-prev").remove();
            $(".layui-laypage-next").remove();
        }
    });
    //选择分类事件
    form.on('select(fid)', function(data){
        table.reload('table', {
            url: api
            ,method: 'post'
            ,limit: 99999
            ,where: {category:data.value}
            ,page: {curr: 1}
        });
    });
    //行点击事件
    table.on('row(table)', function(obj) {
	   obj.setRowChecked({type: 'radio'});
	   tr = $(this);
    });
    table.on('radio(table)', function(obj){
	   tr = $(this).parent().parent().parent();
    });

    //监听工具栏
    table.on('toolbar(table)', function (obj) {
        var checkStatus = table.checkStatus(obj.config.id);
        if( checkStatus.data.length == 0 && ['refresh','save','tip'].indexOf(obj.event) == -1 ) {
            layer.msg('未选中任何数据！');
            return;
        }
        if(obj.event == 'refresh'){
            table.reload('table');
        }else if(obj.event == 'save'){
            updateSortData();
        }else if(obj.event == 'tip'){
            layer.alert("1.选中需要排序的文章<br />2.按需移动数据位置<br />3.移动好了点击保存即可",{title:'排序提示',anim: 5,closeBtn: 0,btn: ['知道了']});
        }else{
            table_tr_move(obj.event);
        }
    });
    
    //保存排序
    function updateSortData() {
        let new_datas = [];
        let weight = 0;
        $('table tr td[data-field="id"]').each(function(i){
            weight++;
            new_datas.push([$(this).text(),weight]);
        });
        if(new_datas.length == 0){
            layer.msg("表格无数据",{icon:5});
            return;
        }
        console.log(JSON.stringify(new_datas));
        $.post(get_api('write_article','article_sort'),{data:new_datas},function(data,status){
            if(data.code == 1) {
                table.reload('table'); //刷新表
                layer.msg("保存排序成功",{icon:1});
            }else{
                layer.msg(data.msg,{icon:5});
            }
        });
    }

    function table_tr_move(type){
        if(type == 'up_tr' || type == 'up_top'){
            if($(tr).prev().html() == null){
                layer.msg("已经是最顶部了");
                return;
            }
            if(type == 'up_tr'){
                $(tr).insertBefore($(tr).prev()); 
            }else if(type == 'up_top'){
                $(tr).insertBefore($(tr).siblings(":first"));
                roll_tr($(tr).attr("data-index"));
            }
        }else if(type == 'down_tr' || type == 'down_bottom'){
            if($(tr).next().html() == null){
                layer.msg("已经是最底部了");
                return;
            }
            if(type == 'down_tr'){
                $(tr).insertAfter($(tr).next());
            }else if(type == 'down_bottom'){
                $(tr).insertAfter($(tr).siblings(":last"));
                roll_tr($(tr).attr("data-index"));
            }
        }else{
            layer.msg("type参数错误");
            return;
        }
    }

   
    //滚动到指定行
    function roll_tr(index) {
        let cellHtml = $(".layui-table-main").find("tr[data-index=" + index + "]");
        let cellTop = cellHtml.offset().top;
        $(".layui-table-main").scrollTop(cellTop - 160);
    }

});
