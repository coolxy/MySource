<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title><?php echo $theme;?> - 主题配置</title>
  <link rel='stylesheet' href='<?php echo $layui['css']; ?>'>
</head>
<body>
<div class="layui-row" style = "margin-top:18px;">
 <div class="layui-container">
  <div class="layui-col-lg6 layui-col-md-offset3">
   <form class="layui-form" lay-filter="form">
       
    <div class="layui-form-item">
     <label class="layui-form-label">注意</label>
        <div class="layui-input-block">
            <input type="text" placeholder="未完全本地化,内网用户不可用" autocomplete="off" class="layui-input" disabled >
        </div>
    </div>
    
    <div class="layui-form-item">
     <label class="layui-form-label">鸿蒙字体</label>
      <div class="layui-input-inline">
       <select lay-verify="required" name="HarmonyOS_Sans">
        <option value="0">关闭</option>
        <option value="1">开启</option>
       </select>
      </div>
     <div class="layui-form-mid layui-word-aux">HarmonyOS Sans 个性字体</div>
    </div>
    
    <div class="layui-form-item">
     <label class="layui-form-label">随机背景</label>
      <div class="layui-input-inline">
       <select lay-verify="required" name="bg_img">
        <option value="1">内置壁纸</option>
        <option value="2">每日必应</option>
        <option value="3">随机风景(加载慢)</option>
        <option value="4">随机动漫(加载慢)</option>
       </select>
      </div>
     <div class="layui-form-mid layui-word-aux">随机背景图</div>
    </div>
    
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">Logo图像</label>
        <div class="layui-input-block">
            <input type="text" name="logo_img" placeholder="./templates/guide/imsyy-home/img/icon/logo.png" autocomplete="off" class="layui-input" style="padding-left: 65px;">
            <i class="layui-icon layui-icon-upload-drag layui-btn layui-btn-primary" style="position: absolute; top:0px;" title="上传"></i>
        </div>
    </div>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">Logo大文本</label>
        <div class="layui-input-block">
            <input type="text" name="logo_text_1" placeholder="" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">Logo小文本</label>
        <div class="layui-input-block">
            <input type="text" name="logo_text_2" placeholder="" autocomplete="off" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">介绍标题</label>
        <div class="layui-input-block">
            <input type="text" name="des_title" placeholder="Hello World !" autocomplete="off" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">介绍内容</label>
        <div class="layui-input-block">
            <input type="text" name="des_text" placeholder="一个建立于 21 世纪的小站，存活于互联网的边缘" autocomplete="off" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">Github</label>
        <div class="layui-input-block">
            <input type="text" name="github" placeholder="没有可以不填" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">QQ</label>
        <div class="layui-input-block">
            <input type="text" name="qq" placeholder="没有可以不填" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">Email</label>
        <div class="layui-input-block">
            <input type="text" name="email" placeholder="没有可以不填" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">bilibili</label>
        <div class="layui-input-block">
            <input type="text" name="bilibili" placeholder="没有可以不填" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">Telegram</label>
        <div class="layui-input-block">
            <input type="text" name="telegram" placeholder="没有可以不填" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item">
     <label class="layui-form-label">显示天气</label>
      <div class="layui-input-inline">
       <select lay-verify="required" name="Weather">
        <option value="0">不显示</option>
        <option value="1">显示</option>
       </select>
      </div>
     <div class="layui-form-mid layui-word-aux"> <a href="https://www.mxnzp.com/doc/detail?id=7&from=twonav" style="color: #0092ff;" target="_Blank">免费申请key</a></div>
    </div>
    
    <div class="layui-form-item">
     <label class="layui-form-label">注意</label>
        <div class="layui-input-block">
            <input type="text" placeholder="点击上方申请Key并填入下方" autocomplete="off" class="layui-input" disabled >
        </div>
    </div>
    
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">app_id</label>
        <div class="layui-input-block">
            <input type="text" name="app_id" placeholder="点击上方申请Key后填入" autocomplete="off" class="layui-input">
        </div>
    </div>
    <div class="layui-form-item layui-form-text">
        <label class="layui-form-label">app_secret</label>
        <div class="layui-input-block">
            <input type="text" name="app_secret" placeholder="点击上方申请Key后填入" autocomplete="off" class="layui-input">
        </div>
    </div>
    
    <div class="layui-form-item">
     <label class="layui-form-label">使用说明</label>
     <div class="layui-form-mid layui-word-aux"> <a href="./templates/guide/imsyy-home/doc.txt" style="color: #0092ff;" target="_Blank">自定义链接说明</a></div>
    </div>

    <div class="layui-form-item">
     <label class="layui-form-label">4号链接</label>
      <div class="layui-input-block">
       <textarea name="link_4" rows ="2" placeholder="" class="layui-textarea"></textarea>
      </div>
    </div>
    <div class="layui-form-item">
     <label class="layui-form-label">5号链接</label>
      <div class="layui-input-block">
       <textarea name="link_5" rows ="2" placeholder="" class="layui-textarea"></textarea>
      </div>
    </div>
    <div class="layui-form-item">
     <label class="layui-form-label">6号链接</label>
      <div class="layui-input-block">
       <textarea name="link_6" rows ="2" placeholder="" class="layui-textarea"></textarea>
      </div>
    </div>
    
    
    <div class="layui-form-item" style="padding-top: 10px;">
     <div class="layui-input-block">
         <button class="layui-btn" lay-submit lay-filter="save">保存</button>
     </div>
    </div>
   </form>
  </div>
 </div>
</div>
<script src = '<?php echo $libs?>/jquery/jquery-3.6.0.min.js'></script>
<script src = '<?php echo $layui['js']; ?>'></script>
<script src = "./templates/admin/js/public.js?v=<?php echo $Ver;?>"></script>

<script>
var u = '<?php echo $u?>';
var t = '<?php echo $theme;?>';
var s = '<?php echo $_GET['source'];?>';
var api = get_api('write_theme','config') + '&t=' + t  + '&fn=' + _GET('fn');
layui.use(['form'], function(){
    var form = layui.form;
    //表单赋值
    form.val('form', <?php echo json_encode($theme_config);?>);
    
    form.on('submit(save)', function(data){
        $.post(api,data.field,function(data,status){
            if(data.code == 1) {
                if (s == 'admin'){
                    layer.msg(data.msg, {icon: 1});
                    return false;
                }else{
                    layer.msg(data.msg, {icon: 1});
                    setTimeout(() => {parent.location.reload();}, 500);
                }
            }else{
                layer.msg(data.msg, {icon: 5});
            }
            });
    return false; 
    });
     //上传图片
    layui.upload.render({
        elem: '.layui-icon-upload-drag',
        url: get_api('write_upload_img','root'),
        exts: 'jpg|jpeg|png|bmp|gif|ico|svg|webp', 
        acceptMime:  'image/*',
        size: 10240,
        done: function(res, index, upload){
            if(res.code == '1'){
                $(this.item).closest('.layui-form-item').find('input[type="text"]').val(res.url);
                layer.msg('上传成功');
            }else{
                layer.msg('上传失败,' + res.msg, {icon: 5});
            }
        }
    });
});
</script>
</body>
</html>