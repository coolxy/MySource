<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta http-equiv="Access-Control-Allow-Origin" content="*">
    <meta name="renderer" content="webkit" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="force-rendering" content="webkit" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#424242" />
    <meta name="keywords" content="<?php echo $s_site['keywords']; ?>">
    <meta name="description" content="<?php echo $s_site['description']; ?>">
    <meta name="author" content="無名">
    <title><?php echo $s_site['title'];?></title>
    <script src="https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-y/jquery/3.5.1/jquery.min.js"></script>
    <?php if($theme_config['HarmonyOS_Sans'] == '1') { ?> 
    <!-- HarmonyOS Sans -->
    <link rel="stylesheet" href="https://s1.hdslb.com/bfs/static/jinkela/long/font/regular.css" />
    <?php } ?> 
    <!-- 引入样式 -->
    <link rel="stylesheet" type="text/css" href="https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-y/bootstrap/5.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $theme_dir;?>/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $theme_dir;?>/css/mobile.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $theme_dir;?>/css/loading.css">
    <link rel="stylesheet" type="text/css" href="<?php echo $theme_dir;?>/css/animation.css">
    <link rel="shortcut icon" href="<?php echo $favicon;?>">
    <!-- Izitoast -->
    <link rel="stylesheet" href="https://lf3-cdn-tos.bytecdntp.com/cdn/expire-1-y/izitoast/1.4.0/css/iziToast.min.css">
    <script type="text/javascript" src="https://lf26-cdn-tos.bytecdntp.com/cdn/expire-1-y/izitoast/1.4.0/js/iziToast.min.js"></script>
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdn.bootcdn.net/ajax/libs/font-awesome/6.1.2/css/all.min.css">
</head>

<body>
    <!--加载动画-->
    <div id="loading-box">
        <div class="loading-left-bg"></div>
        <div class="loading-right-bg"></div>
        <div class="spinner-box">
            <div class="loader">
                <div class="inner one"></div>
                <div class="inner two"></div>
                <div class="inner three"></div>
            </div>
            <div class="loading-word">
                <p class="loading-title" id="loading-title"><?php echo $s_site['title']; ?></p>
                <span id="loading-text">加载中</span>
            </div>
        </div>
    </div>
    <section id="section" class="section">
        <!-- 背景图片 -->
        <div class="bg-all">
            <img id="bg" onerror="this.classList.add('error');"></img>
            <div class="cover"></div>
        </div>
        <!-- 鼠标指针 -->
        <div id="g-pointer-1"></div>
        <div id="g-pointer-2"></div>
        <!-- 主体内容 -->
        <main id="main" class="main">
            <div class="container" id="container">
                <div class="row" id="row">
                    <div class="col left">
                        <!--基本信息-->
                        <div class="main-left">
                            <!--Logo-->
                            <div class="main-img">
                                <img id="logo-img" src="<?php echo $theme_config['logo_img'];?>" alt="img">
                                <div class="img-title">
                                    <span class="img-title-big" id="logo-text-1"><?php echo $theme_config['logo_text_1'];?></span>
                                    <span class="img-text" id="logo-text-2"><?php echo $theme_config['logo_text_2'];?></span>
                                </div>
                            </div>
                            <!--介绍信息-->
                            <div class="message cards" id="switchmore">
                                <div class="des" id="des">
                                    <i class="fa-solid fa-quote-left"></i>
                                    <div class="des-title"><span id="change"><?php echo $theme_config['des_title'];?></span><br /><span
                                            id="change1"><?php echo $theme_config['des_text'];?></span></div>
                                    <i class="fa-solid fa-quote-right"></i>
                                </div>
                            </div>
                            <!--社交链接-->
                            <div class="social" id="social"></div>
                        </div>
                    </div>
                    <!--第二屏 Logo-->
                    <div class="logo cards" style="display: none" id="changemore">
                        <a class="logo-text" id="logo-text-small"><?php echo $_SERVER['HTTP_HOST'] ?></a>
                    </div>
                    <div class="col right">
                        <div class="main-right">
                            <!--功能区-->
                            <div class="row rightone" id="rightone">
                                <div class="col hitokotos">
                                    <!--一言-->
                                    <div class="hitokoto cards" id="hitokoto">
                                        <div class="hitokoto-all">
                                            <div class="hitokoto-text"><span id="hitokoto_text">每一个人都应该明确自己的方向和位置</span></div>
                                            <div class="hitokoto-from">-「&nbsp;<span id="from_text">無名</span>&nbsp;」
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col times">
                                    <!--时间-->
                                    <div class="time cards" id="upWeather">
                                        <div class="timeshow" id="time">
                                            2000&nbsp;年&nbsp;0&nbsp;月&nbsp;00&nbsp;日&nbsp;<span
                                                class="weekday">星期一</span><br><span class="time-text">00:00:00</span>
                                        </div>
                                        <div class="weather">
                                            <span id="city_text">天气</span>&nbsp;
                                            <span id="wea_text">加载失败</span>&nbsp;
                                            <span id="tem_text"></span>
                                            <span id="win_text">次数</span>
                                            <span id="win_speed">超限</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--分隔线-->
                            <div class="line">
                                <!--<i class="fa-solid fa-link"></i>-->
                                <!--<span class="line-text">网站列表</span>-->
                            </div>
                            <!--网站链接-->
                            <div class="link">
                                <!--第一组-->
                                <div class="row">
                                    <div class="col">
                                        <a id="link-url-1" href="./index.php?c=<?php echo $global_config["Login"];?>" target="_blank">
                                            <div class="link-card cards">
                                                <i id="link-icon-1" class="fa-solid fa-circle-user "></i>
                                                <span class="link-name" id="link-name-1">登录</span>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col 2">
                                        <a id="link-url-2" href="./index.php?c=<?php echo $global_config["Register"];?>" target="_blank">
                                            <div class="link-card cards">
                                                <i id="link-icon-2" class="fa-solid fa-book-bookmark"></i>
                                                <span class="link-name" id="link-name-2">注册</span>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col">
                                        <a id="link-url-3" href="./index.php?c=admin" target="_blank">
                                            <div class="link-card cards">
                                                <i id="link-icon-3" class="fa fa-cog"></i>
                                                <span class="link-name" id="link-name-3">管理</span>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                                <!--第二组-->
                                <div class="row" style="margin-top: 1.5rem;"><?php echo "{$theme_config['link_4']} {$theme_config['link_5']} {$theme_config['link_6']}";?></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--移动端展开菜单按钮-->
                <div class="menu" id="switchmenu">
                    <a class="munu-button cards" id="menu">
                        <i class="fa-solid fa-bars"></i>
                    </a>
                </div>
            </div>
        </main>
        <!-- 版权信息 -->
        <footer id="footer" class="fixed-bottom footer">
            <div class="power">
                <span id="power"><?php echo $copyright;?></span>
                <span id="made">
                    <?php echo $ICP.PHP_EOL;?>
			        <?php echo $global_config['global_footer'].PHP_EOL;?>
                    &nbsp;Theme&nbsp;by&nbsp;<a href="https://github.com/imsyy/home" target="_blank">imsyy</a>
            </div>
        </footer>
    </section>
    <!-- JS -->
    <script>var config = <?php echo json_encode($theme_config)?></script>
    <script type="text/javascript" src="<?php echo $theme_dir;?>/js/main.js"></script>
    <script type="text/javascript" src="<?php echo $theme_dir;?>/js/js.cookie.js"></script>
    <script type="text/javascript" src="https://lf9-cdn-tos.bytecdntp.com/cdn/expire-1-y/bootstrap/5.1.0/js/bootstrap.min.js"></script>
</body>
</html>